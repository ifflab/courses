"""One umbrella-sampling window for Cl- + CH3Cl in water, ML/MM with AIMNet2 + EMLE.
Reaction coordinate xi = d(C-Cl1) - d(C-Cl2). Window i (0 ... 28) is centred at xi0 = -1.4 + 0.1*i A.
Usage: python us_window.py WINDOW"""
import os
import sys
import numpy as np
import openmm as mm
import openmm.unit as u
import sire as sr
from emle.calculator import EMLECalculator

K_US = 300 * u.kilocalorie_per_mole / u.angstrom**2     # umbrella force constant
K_WALL = 600 * u.kilocalorie_per_mole / u.angstrom**2   # wall force constant
R_WALL = 3.0 * u.angstrom                               # walls keep both C-Cl distances below this
T = 300 * u.kelvin

win = int(sys.argv[1])                                  # window index, 0 ... 28

# Solute (molecule 0) with AIMNet2 + EMLE, water with TIP3P, starting from the pre-relaxed structure
mols = sr.load("box.prm7", f"start/win_{win:02d}.rst7")
calc = EMLECalculator(model="sn2_model.mat", backend="aimnet2", alpha_mode="flexible", qm_charge=-1)
qm_mols, engine = sr.qm.emle(mols, mols[0], calc, cutoff="12A")
context = qm_mols.dynamics(temperature="300K", qm_engine=engine, platform="CPU").context()

# Reaction coordinate: atoms C (0), Cl1 (4), Cl2 (5)
xi = mm.CustomCompoundBondForce(3, "distance(p1,p2)-distance(p1,p3)")
xi.addBond([0, 4, 5])

# Window centre: xi0 = -1.4, -1.3, ..., +1.4 A
xi0_A = -1.4 + 0.1 * win
xi0 = xi0_A * u.angstrom

# Umbrella on xi and walls on both C-Cl
umbrella = mm.CustomCVForce("0.5*k*(xi-xi0)^2")
umbrella.addCollectiveVariable("xi", xi)
umbrella.addGlobalParameter("k", K_US)
umbrella.addGlobalParameter("xi0", xi0)
wall = mm.CustomBondForce("step(r-r_wall)*0.5*k_wall*(r-r_wall)^2")
wall.addGlobalParameter("k_wall", K_WALL)
wall.addGlobalParameter("r_wall", R_WALL)
wall.addBond(0, 4)
wall.addBond(0, 5)
context.getSystem().addForce(umbrella)
context.getSystem().addForce(wall)
context.reinitialize(preserveState=True)

# Run 2 ps, saving xi every 10 fs
context.setVelocitiesToTemperature(T)
xi_values = []
for step in range(200):
    context.getIntegrator().step(10)
    xi_values.append(umbrella.getCollectiveVariableValues(context)[0])   # nm
xi_values = (np.array(xi_values) * u.nanometer).value_in_unit(u.angstrom)

os.makedirs("us", exist_ok=True)
k_A = K_US.value_in_unit(u.kilocalorie_per_mole / u.angstrom**2)
np.savez(f"us/win_{win:02d}.npz", xi=xi_values, xi0=xi0_A, k=k_A)    # A, A, kcal/mol/A^2
print(f"window {win}: xi0 = {xi0_A:+.2f}, <xi> = {np.mean(xi_values):+.3f} A")
