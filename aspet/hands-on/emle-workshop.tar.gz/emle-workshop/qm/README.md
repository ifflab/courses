# qm/

Training data: 100 gas-phase DFT calculations (ωB97M-D3BJ/def2-TZVPP, ORCA 6.0.1) of Cl⁻ + CH₃Cl geometries.
- `N.vac.orca` — ORCA output, includes the molecular polarizability
- `N.h5` — MBIS atomic charges and widths (HORTON)
File names must stay `0, 1, 2, …` (no leading zeros) for `tarball-to-extxyz`.
