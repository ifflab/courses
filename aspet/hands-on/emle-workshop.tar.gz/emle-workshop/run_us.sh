#!/bin/bash
#SBATCH --job-name=umbrella
#SBATCH --account=tra26_tccm
#SBATCH --partition=dcgp_usr_prod
#SBATCH --qos=dcgp_qos_dbg
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=29
#SBATCH --time=00:30:00
#SBATCH --output=umbrella.log

# Software from this folder (same as "pixi shell")
eval "$(pixi shell-hook)"

# One CPU core per window
export OMP_NUM_THREADS=1 OPENMM_CPU_THREADS=1

# All 29 windows at the same time, then the free-energy profile
seq 0 28 | xargs -P 29 -n 1 python us_window.py
python pmf.py us/*.npz
