# start/

`win_NN.rst7`: Amber restart files (coordinates in Å + box) of the whole system for window NN
(xi0 = −1.4 + 0.1·NN Å), already relaxed with the same model, so the windows need no equilibration.
Windows 15–28 are windows 13–0 with the coordinates of Cl1 and Cl2 swapped (xi → −xi; both Cl have identical
parameters in `box.prm7`).
Topology: `../box.prm7`.
