"""Free-energy profile F(xi) with WHAM from the umbrella windows given on the command line.
Usage: python pmf.py us/*.npz   ->  pmf.dat, pmf.png"""
import sys
import numpy as np
import matplotlib.pyplot as plt

KT = 0.0019872 * 300.0                          # kcal/mol
BIN_WIDTH = 0.05                                # A; a window spreads over sd = sqrt(KT/k) = 0.045 A at k = 300


def histogram(xi_values, bins):
    """Number of xi samples of one window in each bin"""
    counts, _ = np.histogram(xi_values, bins)
    return counts


def wham(hist, xi, xi0, k):
    """Free energy (kcal/mol, minimum = 0) at bin centres xi from the window histograms
    (window x bin) of umbrellas with centres xi0 and force constants k."""
    bias = np.exp(-0.5 * k[:, None] * (xi - xi0[:, None]) ** 2 / KT)   # Boltzmann factor of each umbrella
    N = hist.sum(axis=1)                        # number of samples in each window
    Z = np.ones(len(hist))                      # window partition functions
    # WHAM equations, solved by iteration: the unbiased probability P of each bin combines all windows,
    # each window weighted by its number of samples and its bias; Z then follows from P
    for _ in range(10000):
        P = hist.sum(axis=0) / ((N / Z) @ bias)
        Z = bias @ P
    F = -KT * np.log(P)                         # free energy from probability
    return F - F.min()


# Read the windows: xi samples, window centre xi0 and force constant k
windows = [np.load(f) for f in sys.argv[1:]]
samples = [w["xi"] for w in windows]
xi0 = np.array([w["xi0"] for w in windows])
k = np.array([w["k"] for w in windows])

# Histogram of each window on common bins covering all samples
all_xi = np.concatenate(samples)
bins = np.arange(all_xi.min(), all_xi.max() + BIN_WIDTH, BIN_WIDTH)
xi = 0.5 * (bins[1:] + bins[:-1])              # bin centres
hist = np.array([histogram(s, bins) for s in samples])
sampled = hist.sum(axis=0) > 0                  # drop empty bins
xi, hist = xi[sampled], hist[:, sampled]

# Free-energy profile, then barrier and reaction free energy relative to the reactant minimum
F = wham(hist, xi, xi0, k)
ts = np.argmax(F)                               # transition state: highest point
F_reactant, F_product = F[:ts].min(), F[ts:].min()   # lowest points before and after it
print(f"barrier = {F[ts] - F_reactant:.1f} kcal/mol, reaction free energy = {F_product - F_reactant:.1f} kcal/mol")

# Save the profile as a table and as a plot
np.savetxt("pmf.dat", np.column_stack([xi, F]), fmt="%.3f", header="xi (A)  F (kcal/mol)")
plt.plot(xi, F)
plt.xlabel("xi (A)")
plt.ylabel("F (kcal/mol)")
plt.savefig("pmf.png", dpi=150)
