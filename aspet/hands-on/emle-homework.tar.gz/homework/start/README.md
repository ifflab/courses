# start/

`win_NN.rst7`: Amber restart files (coordinates in Å + box) of the whole system for window NN
(xi0 = −1.7 + 0.1·NN Å), relaxed for 20 ps with the same model and umbrella, so the windows need no equilibration.
Topology: `../box.prm7`.
