# qm/

100 DFT calculations of NH₃ + CH₃Cl (ωB97M-D3BJ/def2-TZVPP, ORCA): `N.vac.orca` (output with the polarizability)
and `N.h5` (MBIS atomic charges and sizes). Geometries from gas-phase AIMNet2 umbrella sampling along the reaction.
